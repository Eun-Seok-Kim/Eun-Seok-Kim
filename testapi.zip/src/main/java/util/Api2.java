package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import vo.ApiVo;

public class Api2 {
	    public static void main(String[] args) throws IOException {
	    	try {
	    	String serviceKey ="HUGsei948k7GTAIm951Gwaph5wGoiBzWrH7jKaVNWZ56lzC84RVFoXia4FQqpBlT3ncDyVnrgO%2BGaIG0gvp%2BOQ%3D%3D";
			String keyword = URLEncoder.encode("�¾�","UTF-8");
			String urlBuilder = "http://api.visitkorea.or.kr/openapi/service/rest/GoCamping/searchList?" + "serviceKey="+ serviceKey +"&MobileOS=ETC"+"&MobileApp=AppTest"+"&keyword="+keyword+"&_type=json";
			
	        //urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*���� ��������ȣ*/
	        //urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*�� ������ ��� ��*/
	       
			URL url = new URL(urlBuilder);
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-type", "application/json");
	        //System.out.println("Response code: " + conn.getResponseCode());
	        BufferedReader rd;
	        if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) {
	            rd = new BufferedReader(new InputStreamReader(conn.getInputStream(),"UTF-8"));
	        } else {
	            rd = new BufferedReader(new InputStreamReader(conn.getErrorStream(),"UTF-8"));
	        }
	        String sb = "";
	        //StringBuilder sb = new StringBuilder();
	        String line;
	        while ((line = rd.readLine()) != null) {	        	
	            sb = sb.concat(line);
	           // System.out.println(sb);
	        JSONParser parser = new JSONParser();
	        
	        JSONObject obj = (JSONObject) parser.parse(sb);
	        JSONObject parse_response = (JSONObject) obj.get("response");
			JSONObject parse_body = (JSONObject) parse_response.get("body");
			JSONObject parse_items = (JSONObject) parse_body.get("items");			
			JSONArray parse_item = (JSONArray) parse_items.get("item");
			
			JSONObject camping_data;
			ApiVo vo = new ApiVo();
			String p_name,p_addr,p_tel,p_filename;
			double p_x,p_y;
			for(int i=0; i<parse_item.size(); i++) {
				camping_data = (JSONObject) parse_item.get(i);

				p_name=((String) camping_data.get("facltNm"));
				p_addr=((String) camping_data.get("addr1"));
				p_tel=((String) camping_data.get("tel"));
				p_filename=((String) camping_data.get("firstImageUrl"));
				p_x=((double) camping_data.get("mapX"));
				p_y=((double) camping_data.get("mapY"));
				System.out.printf("ķ���� �� : %s\r\n",p_name);
				System.out.printf("ķ���� �ּ� : %s\r",p_addr);
				System.out.printf("ķ���� ��ȣ : %s\r",p_tel);
				System.out.printf("ķ���� ���� : %f\r",p_x);
				System.out.printf("ķ���� �浵 : %f\r",p_y);

			}
			
			
	        
	        rd.close();
	        conn.disconnect();
	       // System.out.println(sb.toString());
	        }
	    }
	    
	    catch
		(Exception e)
		{
	    	System.out.println(e.getMessage());
		}
}
}
