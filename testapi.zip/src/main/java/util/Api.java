package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class Api {

    	

    	 public static void main(String[] args){
    	    		try {

					String serviceKey ="HUGsei948k7GTAIm951Gwaph5wGoiBzWrH7jKaVNWZ56lzC84RVFoXia4FQqpBlT3ncDyVnrgO%2BGaIG0gvp%2BOQ%3D%3D";
					String keyword = URLEncoder.encode("��⵵","utf-8");
					String urlBuilder = "http://api.visitkorea.or.kr/openapi/service/rest/GoCamping/searchList?" + "serviceKey="+ serviceKey +"&MobileOS=ETC"+"&MobileApp=AppTest"+"&keyword="+keyword+"&_type=json"; /*URL*/
					//urlBuilder.append("?" + URLEncoder.encode("serviceKey","UTF-8") + "="+ serviceKey); /*Service Key*/
					//urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*���� ��������ȣ*/
					//urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*�� ������ ��� ��*/
					//urlBuilder.append("&" + URLEncoder.encode("MobileOS","UTF-8") + "=" + URLEncoder.encode("ETC", "UTF-8")); /*IOS(������), AND(�ȵ���̵�), WIN(��������), ETC*/
					//urlBuilder.append("&" + URLEncoder.encode("MobileApp","UTF-8") + "=" + URLEncoder.encode("AppTest", "UTF-8")); /*���񽺸�=���ø�*/
					//urlBuilder.append("&" + URLEncoder.encode("keyword","UTF-8") + "=" + keyword); /*�˻� ��û�� Ű����(���ڵ� �ʿ�)*/
					//urlBuilder.append("&_type=json");
					URL url = new URL(urlBuilder);
					//conn = (HttpURLConnection) url.openConnection();
					//conn.setRequestMethod("GET");
					//conn.setRequestProperty("Content-type", "application/json");
					//System.out.println("Response code: " + conn.getResponseCode());
					BufferedReader bf;
					
					/*if(conn.getResponseCode() >= 200 && conn.getResponseCode() <= 300) { 
					    bf = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					} else {
					    bf = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
					}*/
					String result_data = "";
					String line="";
					bf = new BufferedReader(new InputStreamReader(url.openStream())); 
					while ((line = bf.readLine()) != null) {
						result_data = result_data.concat(line);						
						JSONParser parser = new JSONParser();						
						JSONObject obj = (JSONObject) parser.parse(result_data);
						System.out.println(obj);
						JSONObject parse_response = (JSONObject) obj.get("response");
						JSONObject parse_body = (JSONObject) parse_response.get("body");
						JSONObject parse_items = (JSONObject) parse_body.get("items");
						JSONObject parse_item = (JSONObject) parse_items.get("item");						
						
						System.out.println(parse_item);
						
						JSONObject camping_data;
						
						for (int i=0; i < parse_item.length();i++) {
							
							//camping_data = parse_item.get(i);    
							String p_name = (String) parse_item.get("facltNm");
							System.out.println(p_name);
							
						}					
					 bf.close();
					}
    	    		}
    	    		catch
    	    		(Exception e)
    	    		{
    	    			e.getMessage();
    	    		}
    	 
	
}
}

         //JSONParser parser = new JSONParser();   	       
	        //JSONObject obj = (JSONObject) parser.parse(result_data);
	        // JSONObjectjson = parser.parse(result_data);
	        //JSONArray parse_listArr = obj.getJSONArray("list");
 
	        /*or (int i=0;i< parse_listArr.length();i++) {
             JSONObject camping = (JSONObject) parse_listArr.get(i);
             String p_name = (String) camping.get("facltNm");
             String p_addr = (String) camping.get("addr1");            // �߷ɳ�¥
             String p_tel = (String) camping.get("tel");    // �߷�����
             String p_filename = (String) camping.get("firstImageUrl");            // �߷ɱǿ�
             String p_x = (String) camping.get("mapX");        // �߷�����
             String p_y = (String) camping.get("mapY");        // �߷ɽ�
             System.out.printf("��� : %s �ּ� :%s  ��ȭ��ȣ : %s\n ��ǥ���� : %s �浵 : %s ���� : %s",p_addr,p_tel,p_filename,p_x,p_y);                
	        }*/
