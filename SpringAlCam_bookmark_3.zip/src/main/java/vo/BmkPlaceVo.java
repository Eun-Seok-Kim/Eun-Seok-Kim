package vo;

public class BmkPlaceVo {
	
	int    bmk_p_idx;
	int    m_idx;
	String p_name;
	String p_addr;
	String p_tel;
	String p_filename;
	int    p_idx;
	
	public int getBmk_p_idx() {
		return bmk_p_idx;
	}
	public void setBmk_p_idx(int bmk_p_idx) {
		this.bmk_p_idx = bmk_p_idx;
	}
	public int getM_idx() {
		return m_idx;
	}
	public void setM_idx(int m_idx) {
		this.m_idx = m_idx;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_addr() {
		return p_addr;
	}
	public void setP_addr(String p_addr) {
		this.p_addr = p_addr;
	}
	public String getP_tel() {
		return p_tel;
	}
	public void setP_tel(String p_tel) {
		this.p_tel = p_tel;
	}
	public String getP_filename() {
		return p_filename;
	}
	public void setP_filename(String p_filename) {
		this.p_filename = p_filename;
	}
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	
	
	
	

}
