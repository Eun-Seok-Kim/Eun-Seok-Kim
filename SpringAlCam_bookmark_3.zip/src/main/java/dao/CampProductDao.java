package dao;

import vo.CampProductVo;

public interface CampProductDao {
	
	int          insert(CampProductVo vo);

}
