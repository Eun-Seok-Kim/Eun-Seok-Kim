package vo;

public class PlaceVo {

	int    p_idx;
	String p_name;
	String p_addr;
	String p_tel;
	String p_filename;
	double p_x;
	double p_y;
	
	
	
	public int getP_idx() {
		return p_idx;
	}
	public void setP_idx(int p_idx) {
		this.p_idx = p_idx;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_addr() {
		return p_addr;
	}
	public void setP_addr(String p_addr) {
		this.p_addr = p_addr;
	}
	public String getP_tel() {
		return p_tel;
	}
	public void setP_tel(String p_tel) {
		this.p_tel = p_tel;
	}
	public String getP_filename() {
		return p_filename;
	}
	public void setP_filename(String p_filename) {
		this.p_filename = p_filename;
	}
	public double getP_x() {
		return p_x;
	}
	public void setP_x(double p_x) {
		this.p_x = p_x;
	}
	public double getP_y() {
		return p_y;
	}
	public void setP_y(double p_y) {
		this.p_y = p_y;
	}

	
	
	
	
}
